Pursue the Moon README

*********************
   Red Velvet Games
	   presents
Pursue the Moon
*********************

Created and Designed by:
Jason Clark
Eric Gleiser
Garrett Huxtable

************
REQUIREMENTS
************
Windows OS (XP or higher)
Keyboard
Discrete Graphics Card
Powerful Computer

***********
   NOTE
***********
- DO NOT mash on the Space Bar or Enter Key
- This Game Requires a Fast Computer

***********
HOW TO PLAY
***********
- Move the main character with left and right arrow keys.
- When standing in front of an elevator, press spacebar to call
  the elevator to your current position.
- When the doors open, press spacebar again to enter; the doors
  will close behind you.
- Once the elevator doors close, choose the floor you would like
  to go to with the left and right arrow keys. If you decide you
  want to stay on the current floor, simply press spacebar to exit
  the elevator.
- When the floor you wish to go to lights up, press Enter to travel
  to that floor. Once you've arrived, you will automatically exit
  out onto the floor.
- If you find you cannot select a certain floor, you may need a key
  card to access that floor. Key cards have been known to float idly
  in hallways when they wish to be found.
  
***********
  GUIDE
***********
1. Blue Elevator to 5
2. Red Elevator to 7
3. Orange Elevator to 9
4. Purple Elevator to 8
5. Get Green Key Card
6. Green Elevator to 10
7. Gold Elevator to the Moon!